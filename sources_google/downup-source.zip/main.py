from google.cloud import storage
import time

def hello_world(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    source_bucket_name = request.args.get('source_bucket')
    target_bucket_name = request.args.get('target_bucket')
    filename = request.args.get('filename')

    storage_client = storage.Client()

    source_bucket = storage_client.bucket(source_bucket_name)

    start = time.time()
    blob = source_bucket.blob(filename)
    blob.download_to_filename('/tmp/temp_file')

    inter = time.time()

    target_bucket = storage_client.bucket(target_bucket_name)
    upload_blob = target_bucket.blob(filename)
    upload_blob.upload_from_filename('/tmp/temp_file')

    end = time.time()

    return { 
        "upload_time": end - inter, 
        "download_time": inter - start
    }
